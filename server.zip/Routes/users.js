const express = require("express");
const User = require("../Models/User");
const router = express.Router();

router.post("/", async (req, res) => {
    console.log(req.body);
    const user = new User(req.body);
    if (user) {
        await user.save();
        return res.sendStatus(200);
    }
    else {
        res.status(404).send({
            message: `Error: ${req.params.id}: failed to add data`
        });
    }
});

router.get("/", async (req, res) => {
    const users = await User.find({});
    console.log(users);
    res.send(users);
});

router.get("/:id", async (req, res) => {
    console.log(req.params.id);
    const user = await User.findOne({ id: req.params.id });
    if (user) {
        res.send(user);
    }
    else {
        res.status(404).send({
            message: `Error: ${req.params.id}: failed to get data`
        });
    }
});

router.put("/:id", async (req, res) => {
    console.log(req.body, req.params.id);
    const user = await User.findOneAndUpdate({ id: req.params.id }, req.body, {
        new: true,
    });
    if (user) {
        res.send(user);
    } else {
        res.status(404).send({
            message: `Error: ${req.params.id}: failed to update data`
        });
    }
});

router.delete("/:id", async (req, res) => {
    const user = await User.findOneAndDelete({ id: req.params.id });
    if (user) {
        res.send(user);
    } else {
        res.status(404).send({
            message: `Error: ${req.params.id}: failed to delete data`
        });
    }
});

module.exports = router;