const express = require("express");
const Chat = require("../Models/Chat");
const router = express.Router();

router.post("/", async (req, res) => {
    console.log(req.body);
    try {
        const newChat = new Chat(req.body);
        await newChat.save();
        return res.sendStatus(200);
    }
    catch(err) {
        res.status(404).send({
            message: "Error: failed to start a chat"
        });
    }
});

router.get("/", async (req, res) => {
    const chats = await Chat.find({});
    console.log(chats);
    res.send(chats);
});

router.get("/:chat_id", async (req, res) => {
    console.log(req.params.chat_id);
    const chat = await Chat.findOne({ chat_id: req.params.chat_id });
    if (chat) {
        res.send(chat);
    }
    else {
        res.status(404).send({
            message: `Chat Room ${req.params.chat_id} not found.`
        });
    }
});

router.put("/:chat_id", async (req, res) => {
    console.log(req.body, req.params.chat_id);
    const newMessage = {
        username: req.params.username,
        content: req.params.content,
        timestamp: req.params.timestamp
    };
    const chat = await Chat.findOneAndUpdate(
        { chat_id: req.params.chat_id },
        { $push: { messages: newMessage } },
        { new: true }
    );
    if (chat) {
        res.send(chat);
    } else {
        res.status(404).send({
            message: `Chat Room ${req.params.chat_id}: failed to send message`
        });
    }
});

module.exports = router;