const express = require("express");
const app = express();
const socket = require("socket.io");
const http = require("http");
const fs = require("fs");
const chatServer = http.createServer(app);
const io = socket(chatServer);
const mongoose = require("mongoose");
const User = require("./Models/User");
const Chat = require("./Models/Chat");

const MONGO_ID = "knulife_official";
const MONGO_PW = "KEBYU5Bc5CbejXB7";
const MONGO_URI =
    `mongodb+srv://${MONGO_ID}:${MONGO_PW}@knulifeofficial.sugwdph.mongodb.net/?retryWrites=true&w=majority`;

app.use(express.json());

mongoose
    .connect(MONGO_URI)
    .then(() => {
        console.log("Successfully connected to MongoDB");
    })
    .catch((err) => {
        console.log("Failed to connect MongoDB");
    });
 

app.listen(8080, function () {
    console.log("listening on 8080");
});

app.get("/", function (req, res) {
    res.send("This is root page.");
});

app.use("/users", require("./Routes/users"));

app.use("/chats", require("./Routes/chats"));