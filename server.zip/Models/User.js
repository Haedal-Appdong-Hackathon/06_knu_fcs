const mongoose = require("mongoose");
const { availableParallelism } = require("os");

const userSchema = mongoose.Schema({
    id: {
        type: String,
        require: true,
        unique: true,
        minLength: 6
    },
    password: {
        type: String,
        require: true,
        minLength: 8
    },
    name: {
        type: String,
        require: true,
        maxLength: 10
    },
    nickname: {
        type: String,
        maxLength: 8,
        require: true,
        unique: true
    },
    age: {
        type: Number,
        min: 18,
        max: 100,
        require: true,
        default: 20
    },
    sex: {
        type: Number, // Male=0, Female=1
        require: true,
        default: 0
    },
    phone: {
        type: String,
        Length: 11,
        require: true
    },
    department: {
        type: String,
        require: true
    },
    class: {
        type: Number,
        min: 10,
        require: true
    },
    manner: {
        type: Number,
        default: 30
    },
    preference: {
        type: {
            first: {
                type: String
            },
            second: {
                type: String
            },
            third: {
                type: String
            }
        },
        default: {first: "치킨"}
    },
    dislike: {
        type: {
            first: {
                type: String
            },
            second: {
                type: String
            },
            third: {
                type: String
            }
        },
        default: {first: "탕후루"}
    },
    ided: {
        type: Boolean,
        default: false
    }
});

const User = mongoose.model("User", userSchema);

module.exports = User;