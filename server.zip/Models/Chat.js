const mongoose = require("mongoose");
const { availableParallelism } = require("os");

const chatSchema = mongoose.Schema({
    chat_id: {
        type: String,
        require: true,
        unique: true
    },
    messages: {
        type: [
            {
                username: {
                    type: String
                },
                content: {
                    type: String
                },
                timestamp: {
                    type: Date
                }
            }
        ]
    }
});

const Chat = mongoose.model("Chat", chatSchema);

module.exports = Chat;